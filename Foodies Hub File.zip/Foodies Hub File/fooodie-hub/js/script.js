const MENU_ITEMS = [
  { id: 1, name: "Margherita Pizza", category: "Pizza", price: 149, image: "images/pizza/margherita.jpg" },
  { id: 2, name: "Farmhouse Pizza", category: "Pizza", price: 249, image: "images/pizza/farmhouse.jpg" },
  { id: 3, name: "Cheese Burst Pizza", category: "Pizza", price: 299, image: "images/pizza/cheese-burst.jpg" },
  { id: 4, name: "Cheese Burger", category: "Burger", price: 129, image: "images/burger/cheese-burger.jpg" },
  { id: 5, name: "Veggie Burger", category: "Burger", price: 109, image: "images/burger/veggie-burger.jpg" },
  { id: 6, name: "Double Patty Burger", category: "Burger", price: 179, image: "images/burger/double-patty.jpg" },
  { id: 7, name: "Chicken Biryani", category: "Biryani", price: 219, image: "images/biryani/chicken-biryani.jpg" },
  { id: 8, name: "Veg Biryani", category: "Biryani", price: 179, image: "images/biryani/veg-biryani.jpg" },
  { id: 9, name: "Mutton Biryani", category: "Biryani", price: 289, image: "images/biryani/mutton-biryani.jpg" },
  { id: 10, name: "Masala Dosa", category: "South Indian", price: 99, image: "images/south-indian/masala-dosa.jpg" },
  { id: 11, name: "Idly Sambhar", category: "South Indian", price: 79, image: "images/south-indian/idly.jpg" },
  { id: 12, name: "Uttapam", category: "South Indian", price: 109, image: "images/south-indian/uttapam.jpg" },
  { id: 13, name: "Aalu Samosa", category: "Snacks", price: 79, image: "images/snacks/Aalu Samosa.jpg" },
  { id: 14, name: "Corn Samosa", category: "Snacks", price: 149, image: "images/snacks/Corn Samosa.jpg" },
  { id: 15, name: "Samosa with Green Chatani", category: "Snacks", price: 89, image: "images/snacks/Samosa with Green Chatani.jpg" },
  { id: 16, name: "Samosa (2 pc)", category: "Snacks", price: 39, image: "images/snacks/nuggets.jpg" },
  { id: 17, name: "Pasta Alfredo", category: "Pasta", price: 179, image: "images/pasta/alfredo.jpg" },
  { id: 18, name: "Red Sauce Pasta", category: "Pasta", price: 169, image: "images/pasta/red-sauce.jpg" },
  { id: 19, name: "Chocolate Brownie", category: "Dessert", price: 99, image: "images/dessert/brownie.jpg" },
  { id: 20, name: "Sweet Biscuit", category: "Dessert", price: 119, image: "images/dessert/Sweet Biscuit.jpg" },
  { id: 21, name: "Kaju Katali 4 pc)", category: "Dessert", price: 69, image: "images/dessert/Kaju Katali.jpg" },
  { id: 22, name: "Cold Coffee", category: "Drinks", price: 89, image: "images/drinks/cold-coffee.svg" },
  { id: 23, name: "Fresh Lime Soda", category: "Drinks", price: 59, image: "images/drinks/lime-soda.svg" },
  { id: 24, name: "Mango Shake", category: "Drinks", price: 99, image: "images/drinks/mango-shake.svg" },
];

const RESTAURANTS = [
  { id: 1, name: "Spice Villa", cuisine: "North Indian, Biryani", rating: 4.3, distance: "1.2 km", image: "images/restaurants/spice-villa.jpg" },
  { id: 2, name: "Pizza Point", cuisine: "Pizza, Italian", rating: 4.5, distance: "0.8 km", image: "images/restaurants/pizza-point.jpg" },
  { id: 3, name: "Burger Bay", cuisine: "Burgers, Fast Food", rating: 4.1, distance: "2.0 km", image: "images/restaurants/burger-bay.jpg" },
  { id: 4, name: "South Corner", cuisine: "Dosa, Idly, South Indian", rating: 4.4, distance: "1.5 km", image: "images/restaurants/south-corner.jpg" },
  { id: 5, name: "Sweet Treats", cuisine: "Desserts, Bakery", rating: 4.6, distance: "1.0 km", image: "images/restaurants/sweet-treats.jpg" },
  { id: 6, name: "Pasta Junction", cuisine: "Italian, Pasta", rating: 4.0, distance: "2.4 km", image: "images/restaurants/pasta-junction.jpg" },
];

function getCart() {
  const data = localStorage.getItem("foodieHubCart");
  return data ? JSON.parse(data) : {};
}

function saveCart(cart) {
  localStorage.setItem("foodieHubCart", JSON.stringify(cart));
  updateCartCount();
}

function addToCart(itemId) {
  const cart = getCart();
  cart[itemId] = (cart[itemId] || 0) + 1;
  saveCart(cart);
  alert("Added to cart!");
}

function changeQty(itemId, change) {
  const cart = getCart();
  if (!cart[itemId]) return;

  cart[itemId] += change;
  if (cart[itemId] <= 0) delete cart[itemId];

  saveCart(cart);
  renderCartPage();
}

function removeFromCart(itemId) {
  const cart = getCart();
  delete cart[itemId];
  saveCart(cart);
  renderCartPage();
}

function updateCartCount() {
  const cart = getCart();
  let total = 0;
  for (let key in cart) {
    total += cart[key];
  }
  const badge = document.getElementById("cartCount");
  if (badge) badge.textContent = total;
}

function applyTheme(theme) {
  if (theme === "dark") {
    document.body.classList.add("dark");
  } else {
    document.body.classList.remove("dark");
  }
  const btn = document.getElementById("themeToggle");
  if (btn) btn.textContent = theme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode";
}

function toggleTheme() {
  const isDark = document.body.classList.contains("dark");
  const newTheme = isDark ? "light" : "dark";
  localStorage.setItem("foodieHubTheme", newTheme);
  applyTheme(newTheme);
}

function loadSavedTheme() {
  const saved = localStorage.getItem("foodieHubTheme") || "light";
  applyTheme(saved);
}

function createFoodCardHTML(item) {
  return (
    '<div class="food-card">' +
      '<img src="' + item.image + '" alt="' + item.name + '" class="food-photo" loading="lazy" />' +
      '<h3>' + item.name + '</h3>' +
      '<p class="price">₹' + item.price + '</p>' +
      '<button class="btn-primary" onclick="addToCart(' + item.id + ')">Add to Cart</button>' +
    '</div>'
  );
}

function renderFoodGrid(container, items) {
  if (!container) return;

  if (items.length === 0) {
    container.innerHTML = '<p class="empty-msg">No items found.</p>';
    return;
  }

  let html = "";
  for (let i = 0; i < items.length; i++) {
    html += createFoodCardHTML(items[i]);
  }
  container.innerHTML = html;
}

function renderHomePage() {
  const container = document.getElementById("popularItems");
  if (!container) return;
  renderFoodGrid(container, MENU_ITEMS.slice(0, 6));
}

function updateHeroGreeting() {
  const heroTitle = document.getElementById("heroTitle");
  if (!heroTitle) return;

  const loggedIn = localStorage.getItem("foodieHubLoggedIn") === "true";
  const savedUser = localStorage.getItem("foodieHubUser");

  if (loggedIn && savedUser) {
    const user = JSON.parse(savedUser);
    heroTitle.textContent = "Welcome back, " + user.name + "! 👋";
  }
}

let currentCategory = "All";

function renderCategoryPage(category, searchTerm) {
  const container = document.getElementById("categoryItems");
  if (!container) return;

  if (category) currentCategory = category;
  const search = (searchTerm || "").trim().toLowerCase();

  let items = MENU_ITEMS;

  if (currentCategory !== "All") {
    items = items.filter(function (item) {
      return item.category === currentCategory;
    });
  }

  if (search) {
    items = items.filter(function (item) {
      return item.name.toLowerCase().indexOf(search) !== -1;
    });
  }

  renderFoodGrid(container, items);

  const chips = document.querySelectorAll(".category-chip");
  chips.forEach(function (chip) {
    if (chip.dataset.category === currentCategory) {
      chip.classList.add("active");
    } else {
      chip.classList.remove("active");
    }
  });
}

function renderRestaurantsPage() {
  const container = document.getElementById("restaurantItems");
  if (!container) return;

  let html = "";
  for (let i = 0; i < RESTAURANTS.length; i++) {
    const r = RESTAURANTS[i];
    html +=
      '<div class="restaurant-card">' +
        '<img src="' + r.image + '" alt="' + r.name + '" class="restaurant-photo" loading="lazy" />' +
        '<div class="restaurant-info">' +
          '<h3>' + r.name + '</h3>' +
          '<p class="cuisine">' + r.cuisine + '</p>' +
          '<p class="restaurant-meta">⭐ ' + r.rating + ' &nbsp;•&nbsp; 📍 ' + r.distance + ' away</p>' +
          '<a href="category.html" class="btn-primary">View Menu</a>' +
        '</div>' +
      '</div>';
  }
  container.innerHTML = html;
}

function renderCartPage() {
  const container = document.getElementById("cartItems");
  if (!container) return;

  const cart = getCart();
  const ids = Object.keys(cart);

  if (ids.length === 0) {
    container.innerHTML = '<p class="empty-msg">Your cart is empty. Go add some tasty food! 🍽️</p>';
    document.getElementById("cartSummary").style.display = "none";
    return;
  }

  document.getElementById("cartSummary").style.display = "block";

  let total = 0;
  let html = "";

  for (let i = 0; i < ids.length; i++) {
    const id = ids[i];
    const item = MENU_ITEMS.find(function (i) { return i.id === Number(id); });
    const qty = cart[id];
    const itemTotal = item.price * qty;
    total += itemTotal;

    html +=
      '<div class="cart-item">' +
        '<img src="' + item.image + '" alt="' + item.name + '" class="cart-photo" />' +
        '<div class="cart-item-info">' +
          '<h3>' + item.name + '</h3>' +
          '<p class="price">₹' + item.price + ' x ' + qty + ' = ₹' + itemTotal + '</p>' +
        '</div>' +
        '<div class="qty-controls">' +
          '<button onclick="changeQty(' + item.id + ', -1)">-</button>' +
          '<span>' + qty + '</span>' +
          '<button onclick="changeQty(' + item.id + ', 1)">+</button>' +
        '</div>' +
        '<button class="remove-btn" onclick="removeFromCart(' + item.id + ')">🗑️</button>' +
      '</div>';
  }

  container.innerHTML = html;
  document.getElementById("cartTotal").textContent = "₹" + total;
}

function checkout() {
  const cart = getCart();
  if (Object.keys(cart).length === 0) {
    alert("Your cart is empty!");
    return;
  }
  alert("🎉 Order placed successfully! Thank you for choosing Fooodie Hub.");
  localStorage.removeItem("foodieHubCart");
  renderCartPage();
  updateCartCount();
}

function signup(name, email, password) {
  const user = { name: name, email: email, password: password };
  localStorage.setItem("foodieHubUser", JSON.stringify(user));
  alert("Signup successful! Please login now.");
  window.location.href = "login.html";
}

function login(email, password) {
  const savedUser = localStorage.getItem("foodieHubUser");

  if (!savedUser) {
    alert("No account found. Please sign up first.");
    return;
  }

  const user = JSON.parse(savedUser);

  if (user.email === email && user.password === password) {
    localStorage.setItem("foodieHubLoggedIn", "true");
    alert("Welcome back, " + user.name + "!");
    window.location.href = "index.html";
  } else {
    alert("Wrong email or password. Try again.");
  }
}

function logout() {
  localStorage.removeItem("foodieHubLoggedIn");
  alert("You have been logged out.");
  window.location.href = "index.html";
}

function updateAuthLink() {
  const authLink = document.getElementById("authLink");
  if (!authLink) return;

  const loggedIn = localStorage.getItem("foodieHubLoggedIn") === "true";
  const savedUser = localStorage.getItem("foodieHubUser");
  const user = savedUser ? JSON.parse(savedUser) : null;

  if (loggedIn && user) {
    authLink.textContent = "Logout (" + user.name + ")";
    authLink.href = "#";
    authLink.onclick = function (e) {
      e.preventDefault();
      logout();
    };
  } else {
    authLink.textContent = "Login";
    authLink.href = "login.html";
    authLink.onclick = null;
  }
}

document.addEventListener("DOMContentLoaded", function () {
  loadSavedTheme();
  updateCartCount();
  updateAuthLink();
  updateHeroGreeting();
  renderHomePage();
  renderCategoryPage("All", "");
  renderCartPage();
  renderRestaurantsPage();

  const toggleBtn = document.getElementById("themeToggle");
  if (toggleBtn) toggleBtn.addEventListener("click", toggleTheme);

  document.querySelectorAll(".category-chip").forEach(function (chip) {
    chip.addEventListener("click", function () {
      const searchBox = document.getElementById("searchInput");
      renderCategoryPage(chip.dataset.category, searchBox ? searchBox.value : "");
    });
  });

  const searchBox = document.getElementById("searchInput");
  if (searchBox) {
    searchBox.addEventListener("input", function () {
      renderCategoryPage(currentCategory, searchBox.value);
    });
  }

  const homeSearchForm = document.getElementById("homeSearchForm");
  if (homeSearchForm) {
    homeSearchForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const value = document.getElementById("homeSearchInput").value.trim();
      window.location.href = "category.html?search=" + encodeURIComponent(value);
    });
  }

  const checkoutBtn = document.getElementById("checkoutBtn");
  if (checkoutBtn) checkoutBtn.addEventListener("click", checkout);

  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    signupForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("signupName").value;
      const email = document.getElementById("signupEmail").value;
      const password = document.getElementById("signupPassword").value;
      signup(name, email, password);
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value;
      const password = document.getElementById("loginPassword").value;
      login(email, password);
    });
  }
});
